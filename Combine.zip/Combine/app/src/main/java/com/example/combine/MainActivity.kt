package com.example.combine

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }
    fun showActivity2(view: View){
        val Act2 = Intent(this, MainActivity2::class.java)
        startActivity(Act2)
    }
    fun showActivity3(view: View){
        val Act3 = Intent(this, MainActivity3::class.java)
        startActivity(Act3)
    }
    fun showActivity4(view: View){
        val Act4 = Intent(this, MainActivity4::class.java)
        startActivity(Act4)
    }
    fun showActivity5(view: View){
        val Act5 = Intent(this, MainActivity5::class.java)
        startActivity(Act5)
    }
    fun showActivity6(view: View){
        val Act6 = Intent(this, MainActivity6::class.java)
        startActivity(Act6)
    }

}


