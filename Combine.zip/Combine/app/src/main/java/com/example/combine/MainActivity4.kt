package com.example.combine

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.*

class MainActivity4 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main4)
        val edit_text = findViewById<EditText>(R.id.etxt_msg)
        val cbx_fruit = findViewById<CheckBox>(R.id.cbx_fruit);
        val cbx_meat = findViewById<CheckBox>(R.id.cbx_meat)
        var check_box: String = ""
        var radio_button: String = "One"
        var toggle_button: String = "Off"
        var rating_bar: String = "0.0"
        var fruit = false
        var meat = false
        val rbt_one = findViewById<RadioButton>(R.id.rbt_one)
        val rbt_two = findViewById<RadioButton>(R.id.rbt_two)
        val rbt_three = findViewById<RadioButton>(R.id.rbt_three)
        var rbar_star = findViewById<RatingBar>(R.id.rbar_star)
        var tbtn_power = findViewById<ToggleButton>(R.id.tbtn_power)
        var edit_text2 = edit_text.text


        val btn_text = findViewById<Button>(R.id.btn_text)
        btn_text.setOnClickListener() {
            Toast.makeText(this, "You Clicked Text Button", Toast.LENGTH_SHORT).show();
        }
        val btn_txt_image = findViewById<Button>(R.id.btn_txt_image)
        btn_txt_image.setOnClickListener() {
            Toast.makeText(this, "You Clicked Image Text Button", Toast.LENGTH_SHORT).show();
        }
        val ibtn_image = findViewById<ImageButton>(R.id.ibtn_image)
        ibtn_image.setOnClickListener() {
            Toast.makeText(this, "You Clicked Image Button", Toast.LENGTH_SHORT).show();
        }
        val btn_toast = findViewById<Button>(R.id.btn_toast)
        btn_toast.setOnClickListener() {
            Toast.makeText(
                this,
                "Check Box: " + check_box + "\n" + "Radio Button: " + radio_button + "\n" + "Toggle Button: " + toggle_button + "\n" + "Rating Bar: " + rating_bar + "\n" + "Edit Text: " + edit_text2,
                Toast.LENGTH_LONG
            ).show();


            when {
                cbx_fruit.isChecked -> fruit = true
                !cbx_fruit.isChecked -> fruit = false

            }; when {
            cbx_meat.isChecked -> meat = true
            !cbx_meat.isChecked -> meat = false
        }
            if (fruit && meat) {
                check_box = "Fruit and Meat"
            } else if (meat) {
                check_box = "Meat"
            } else if (fruit) {
                check_box = "Fruit"
            } else {
                check_box = "No Selection"
            }



            rbar_star.rating = 0f
            rbar_star.stepSize = .5f
            rbar_star.setOnRatingBarChangeListener { ratingBar, rating, fromUser ->
                rating_bar = rating.toString()
            }



            if (rbt_one.isChecked) {
                radio_button = "One"
            } else if (rbt_two.isChecked) {
                radio_button = "Two"
            } else if (rbt_three.isChecked) {
                radio_button = "Three"
            } else {
                print("wow")
            }
            when {
                tbtn_power.isChecked -> toggle_button = "On"
                !tbtn_power.isChecked -> toggle_button = "Off"

            }


        }

    }
}