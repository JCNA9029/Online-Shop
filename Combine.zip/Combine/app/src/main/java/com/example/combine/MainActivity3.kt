package com.example.combine

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView

class MainActivity3 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main3)

        val edtxtInput = findViewById<EditText>(R.id.edtxtInput)
        val btnResults = findViewById<Button>(R.id.btnShowResults)
        val txtViewResult = findViewById<TextView>(R.id.txtviewResults)
        var vowels = 0
        var consonants = 0
        var spaces = 0
        var word = edtxtInput.text
        btnResults.setOnClickListener() {
            for (i in 0..word.length - 1) {
                val ch = word[i]
                when (ch) {
                    'a', 'e', 'i', 'o', 'u', 'A', 'E', 'I', 'O', 'U' ->
                        ++vowels
                    in 'a'..'z' -> ++consonants
                    in 'A'..'Z' -> ++consonants
                    ' ' -> ++spaces
                }
                val input = edtxtInput.text.toString()
                val newtext = '*'
                var output = ""
                for (element in input) {
                    output += when (element) {
                        'b', 'c', 'd', 'f', 'g', 'h', 'j', 'k', 'l', 'm',
                        'n', 'p', 'q', 'r', 's', 't', 'v', 'w', 'x', 'y', 'z', 'B',
                        'C', 'D', 'F', 'G', 'H', 'J', 'K', 'L', 'M', 'N',
                        'P', 'Q', 'R', 'S', 'T', 'V', 'W', 'X', 'Y', 'Z' -> { element }
                        ' ' -> { ' ' }
                        else -> {
                            newtext
                        }
                    }
                }
                txtViewResult.text = "There are $vowels Vowels and $consonants Consonants.\n" + output
            }
        }
    }

}