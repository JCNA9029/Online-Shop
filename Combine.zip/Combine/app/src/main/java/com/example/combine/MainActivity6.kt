package com.example.combine

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.EditText
import android.widget.Toast
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase


class MainActivity6 : AppCompatActivity() {
    val db = Firebase.firestore
    private lateinit var name: EditText
    private lateinit var description: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main6)

        name = findViewById(R.id.editText1)
        description = findViewById(R.id.editText2)
    }

    fun fireBase(view: View) {

        val jcna = hashMapOf(
            "name" to name.text.toString(),
            "description" to description.text.toString()
        )

        Toast.makeText(this, "Data successfully saved in FireBase", Toast.LENGTH_SHORT).show()

        db.collection("jcna")
            .add(jcna)
            .addOnSuccessListener { documentReference ->
                Log.d("debug", "DocumentSnapshot added with ID: ${documentReference.id}")
            }
            .addOnFailureListener { e ->
                Log.w("debug", "Error adding document", e)
            }
    }
}