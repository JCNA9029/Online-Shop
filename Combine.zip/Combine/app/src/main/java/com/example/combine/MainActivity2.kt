package com.example.combine

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView

class MainActivity2 : AppCompatActivity() {
    private lateinit var num1 : EditText
    private lateinit var num2 : EditText
    private lateinit var ans : TextView
    private lateinit var add : Button
    private lateinit var sub : Button
    private lateinit var mul : Button
    private lateinit var div : Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main2)
        num1 = findViewById(R.id.edtxtNum1)
        num2 = findViewById(R.id.edtxtNum2)
        add = findViewById(R.id.btnAdd)
        sub = findViewById(R.id.btnSub)
        mul = findViewById(R.id.btnMul)
        div = findViewById(R.id.btnDiv)
        ans = findViewById(R.id.txtAns)


        add.setOnClickListener {
            val input1 = num1.text.toString().toInt()
            val input2 = num2.text.toString().toInt()

            addition(input1, input2)
        }
        sub.setOnClickListener {
            val input1 = num1.text.toString().toInt()
            val input2 = num2.text.toString().toInt()

            subtraction(input1, input2)
        }
        mul.setOnClickListener {
            val input1 = num1.text.toString().toInt()
            val input2 = num2.text.toString().toInt()

            multiplication(input1, input2)
        }
        div.setOnClickListener {
            val input1 = num1.text.toString().toInt()
            val input2 = num2.text.toString().toInt()

            division(input1, input2)
        }
    }
    private fun addition(input1: Int, input2: Int) {
        val res = input1 + input2
        ans.text ="Addition\n" + res.toString()
    }
    private fun subtraction(input1: Int, input2: Int) {
        val res = input1 - input2
        ans.text ="Subtraction\n" + res.toString()
    }
    private fun multiplication(input1: Int, input2: Int) {
        val res = input1 * input2
        ans.text ="Multiplication\n" + res.toString()
    }
    private fun division(input1: Int, input2: Int) {
        val res = input1 / input2
        ans.text ="Division\n" + res.toString()
    }
}